#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include <list>
using namespace std;
using namespace Desdemona;

Turn my_turn;
int depth = 6;
clock_t start,finish;
OthelloBoard main_board;

int avail_valid_moves(char me, char opponent, char square[8][8])   {
    int count = 0;
    for(int i = 0; i < 8; i++){
       for(int j = 0; j < 8; j++){
            bool ans = false;
            if (square[i][j] == 'e'){
            char str[10];
            for (int dy = -1; dy <= 1; dy++){  
                for (int dx = -1; dx <= 1; dx++){
                    if (!dy && !dx) continue;
                    str[0] = '\0';
                    for (int ctr = 1; ctr < 8; ctr++){
                        if ((i + ctr*dx) >= 0 && (j + ctr*dy) >= 0 && (i + ctr*dx)<8 && (j + ctr*dy)<8){
                            str[ctr-1] = square[(i + ctr*dx)][(j + ctr*dy)];  
                        } 
                        else {
                            str[ctr-1] = 0;
                        }
                    }
                    bool move_poss = false;
                    if (str[0] == opponent) {
                        for (int ctr = 1; ctr < 8; ctr++) {
                            if (str[ctr] == 'e') {
                                move_poss = false;
                                break;
                            }
                            if (str[ctr] == me) {
                                move_poss = true;
                                break;
                            }
                        }                    
                    }
    
                    if (move_poss) {
                        ans = true;
                        break;
                    }
                }
                if(ans) break;
            }
            }
            if(ans){
                count++;
            }
       }  
    }
    return count;
}

double board_evaluator(char square[8][8])  {
	char my_color = 'b',opp_color = 'r';
    int my_square = 0, opp_square = 0, i, j, k, my_front_squares = 0, opp_front_squares = 0, x, y;
    double p = 0.0, c = 0.0, l = 0.0, m = 0.0, f = 0.0, d = 0.0;

    int X1[] = {-1, -1, 0, 1, 1, 1, 0, -1};
    int Y1[] = {0, 1, 1, 1, 0, -1, -1, -1};
    int board_values[8][8] = 	{ { 40, -6, 22, 16, 16, 22, -6, 40 },
    				{ -6, -14, -8, 2, 2, -8, -14, -6 },
    				{ 22, -8, 4, 4, 4, 4, -8, 22 },
    				{ 16, 2, 4, -6, -6, 4, 2, 16 },
    				{ 16, 2, 4, -6, -6, 4, 2, 16 },
    				{ 22, -8, 4, 4, 4, 4, -8, 22 },
    				{ -6, -14, -8, 2, 2, -8, -14, -6 },
    				{ 40, -6, 22, 16, 16, 22, -6, 40 } };

	// calculate Piece difference
    for(i = 0; i < 8; i++)
        for(j = 0; j < 8; j++)  {
            if(square[i][j] == my_color)  {
                d += board_values[i][j];
                my_square++;
            } 
            else if(square[i][j] == opp_color)  {
                d -= board_values[i][j];
                opp_square++;
            }
            if(square[i][j] != 'e')   {
                for(k = 0; k < 8; k++)  {
                    x = i + X1[k]; y = j + Y1[k];
                    if(x >= 0 && x < 8 && y >= 0 && y < 8 && square[x][y] == 'e') {
                        if(square[i][j] == my_color)  my_front_squares++;
                        else opp_front_squares++;
                        break;
                    }
                }
            }
        }

    if(my_square > opp_square) p = (100.0 * my_square)/(my_square + opp_square);
    else if(my_square < opp_square) p = -(100.0 * opp_square)/(my_square + opp_square);

    if(my_front_squares > opp_front_squares) f = -(100.0 * my_front_squares)/(my_front_squares + opp_front_squares);
    else if(my_front_squares < opp_front_squares) f = (100.0 * opp_front_squares)/(my_front_squares + opp_front_squares);

    // calculate Corner closeness and Corner occupancy
    int corners[4][2] = {{0,0},{0,7},{7,0},{7,7}};

    my_square = opp_square = 0;
    for(int i=0;i<4;i++){
    	if(square[corners[i][0]][corners[i][1]] == 'e'){
    		for(int row=corners[i][0]-1;row<=corners[i][0]+1;row++){
	    		for(int column=corners[i][1]-1;column<=corners[i][1]+1;column++){
	    			if(row>=0 && row<=7 && column>=0 && column<=7){
	    				if(square[0][1] == my_color) my_square++;
        				else if(square[0][1] == opp_color) opp_square++;
        			}
    			}
    		}
    	}	
    }
    l = -12.5 * (my_square - opp_square);

    my_square = opp_square = 0;
    for(int i=0;i<4;i++){
    	if(square[corners[i][0]][corners[i][1]] == my_color) my_square++;
    	else if(square[corners[i][0]][corners[i][1]] == opp_color) opp_square++;	
    }
    c = 25 * (my_square - opp_square);

    // calculate Mobility
    my_square = avail_valid_moves(my_color, opp_color, square);
    opp_square = avail_valid_moves(opp_color, my_color, square);
    if(my_square > opp_square) m = (100.0 * my_square)/(my_square + opp_square);
    else if(my_square < opp_square) m = -(100.0 * opp_square)/(my_square + opp_square);

    // calculate final weighted score
    double score = (10 * p) + (801.724 * c) + (382.026 * l) + (78.922 * m) + (74.396 * f) + (10 * d);
    return score;
}

double getvalue_my_move(OthelloBoard board, Move move, Turn turn, int level, double alpha, double beta) {
    finish = clock();
    if(((double)(finish-start)/CLOCKS_PER_SEC)>1.75) {
        if(level%2==1) return -1e18;
        return 1e18;
    }
	if(level == depth) {
		char square[8][8];
		for(int i=0;i<8;i++) {
			for(int j=0;j<8;j++) {
				Coin findTurn = board.get(i,j);
				if(findTurn == turn) square[i][j] = 'r';
				else if(findTurn == other(turn)) square[i][j] = 'b';
				else square[i][j] = 'e';
			}
		}
		return board_evaluator(square);
	}
	board.makeMove(turn,move);
	turn = other(turn);
    double value = -1e18;
	list<Move> new_moves = board.getValidMoves(turn);
	list<Move>::iterator iter = new_moves.begin();
	if(level%2==1) value *= -1;
	if(!(new_moves.size())) return value;
	while(iter!=new_moves.end()) {
		double curr = getvalue_my_move(board,*iter,turn,level+1,alpha,beta);
		if(level%2==1) {
			value = min(value,curr);
			beta = min(beta,value);
		}
		else {
			value = max(value,curr);
			alpha = max(alpha,value);		
		}
		if(beta<=alpha) {
            break;
        }
        iter++;
	}
	return value; 
}

double move_test(OthelloBoard board,Turn turn) {
    char square[8][8];
    for(int i=0;i<8;i++) {
        for(int j=0;j<8;j++) {
        Coin findTurn = board.get(i,j);
        if(findTurn == turn) square[i][j] = 'b';
        else if(findTurn == other(turn)) square[i][j] = 'r';
        else square[i][j] = 'e';
        }
    }
    return board_evaluator(square);
}

bool move_compare(Move m1, Move m2) {
    OthelloBoard board1 = main_board,board2 = main_board;
    board1.makeMove(my_turn,m1);
    board2.makeMove(my_turn,m2);
    return move_test(board1,my_turn)>move_test(board2,my_turn);
}

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

Move MyBot::play( const OthelloBoard& board )
{
    start = clock();
    my_turn = turn;
    OthelloBoard stored_board = board;
    double value = -1e18, MAX = 1e18, MIN = -1e18;
    int level = 1;
    main_board = board;
    list<Move> moves = board.getValidMoves( turn );
    moves.sort(move_compare);
    list<Move>::iterator it = moves.begin();
    Move bestMove((*it).x,(*it).y);
    
    while(it!=moves.end()) {
    	double currValue = getvalue_my_move(stored_board,*it,turn,level,MIN,MAX);
    	if(currValue > value) {
    		value = currValue;
    		bestMove = *it;
    	}
    	stored_board = board;
        it++;
    }
    return bestMove;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}